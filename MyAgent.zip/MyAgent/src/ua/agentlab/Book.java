package ua.agentlab;

public class Book
{
	String title;
	Integer price;
	public Book(String t, Integer p)
	{
		title=t;
		price=p;
	}
}